<%-- 
    Document   : feeCalculator
    Created on : 14 Apr 2026, 1:20:02 pm
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Fee Calculator</title>
    </head>

    <body>

        <%@ include file="header.jsp" %>

        <h3>Membership Fee Calculator</h3>

        <form method="get">
            Number of Activities:
            <input type="text" name="activities"><br>
            <input type="submit" value="Calculate">
        </form>

        <%
            String act = request.getParameter("activities");
            double total = 0;

            if (act != null) {
                int activities = Integer.parseInt(act);
                total = activities * 10;
        %>

        <p>Total Fee: RM <%= String.format("%.2f", total)%></p>

        <%
            }
        %>

        <%@ include file="footer.jsp" %>

    </body>
</html>