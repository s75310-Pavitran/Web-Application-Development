<%-- 
    Document   : footer
    Created on : 14 Apr 2026, 1:18:51?pm
    Author     : Admin
--%>

<div style="background-color:#ffe4c4; padding:10px; text-align:center; margin-top:20px;">
    <p>&copy;2026-Pavitran</p>
</div>