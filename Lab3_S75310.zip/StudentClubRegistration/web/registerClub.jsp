<%-- 
    Document   : registerPage
    Created on : 14 Apr 2026, 1:19:25 pm
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Register Club</title>
</head>
<body>
    <%@ include file="header.jsp" %>
    <h3>Club Registration</h3>
    <form action="processRegistration.jsp" method="post">
        Name: <input type="text" name="name" required><br><br>
        Matric No: <input type="text" name="matric" required><br><br>
        Club:
        <select name="club">
            <option>COMTECH Club</option>
            <option>HIMMAT Club</option>
            <option>UMT Gaming Club</option>
            <option>UMT Band</option>
        </select><br><br>
        <input type="submit" value="Register">
    </form>
    <%@ include file="footer.jsp" %>
</body>
</html>