<%-- 
    Document   : processRegistration
    Created on : 14 Apr 2026, 1:20:28?pm
    Author     : Admin
--%>

<%@page import="java.util.*"%>
<%

    String name = request.getParameter("name");
    String matric = request.getParameter("matric");
    String club = request.getParameter("club");

    List<Map<String, String>> memberList = (List<Map<String, String>>) application.getAttribute("globalList");

    if (memberList == null) {
        memberList = new ArrayList<>();
        application.setAttribute("globalList", memberList);
    }

    if (name != null && !name.trim().isEmpty()) {
        Map<String, String> user = new HashMap<>();
        user.put("name", name);
        user.put("matric", matric);
        user.put("club", club);

        memberList.add(user);
    }

    response.sendRedirect("memberDirectory.jsp");
%>