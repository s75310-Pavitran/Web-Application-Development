<%-- 
    Document   : header
    Created on : 14 Apr 2026, 1:18:43?pm
    Author     : Admin
--%>

<div style="background-color:#ffe4c4; padding:15px; text-align:center;">
    <h2>UMT Student Club System</h2>

    <a href="registerClub.jsp">Registration</a> |
    <a href="feeCalculator.jsp">Fee Calculator</a> |
    <a href="memberDirectory.jsp">Member Directory</a>
</div>