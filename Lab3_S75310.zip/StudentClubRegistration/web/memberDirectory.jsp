<%-- 
    Document   : memberDirectory
    Created on : 14 Apr 2026, 1:21:07 pm
    Author     : Admin
--%>

<%@page import="java.util.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Member Directory</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <h2>Member Directory</h2>

        <table border="1" style="width:100%; text-align:left;">
            <tr style="background-color:#eee;">
                <th>Name</th>
                <th>Matric No</th>
                <th>Club</th>
            </tr>
            <%
                // Pull the list from the application scope
                List<Map<String, String>> list = (List<Map<String, String>>) application.getAttribute("globalList");

                if (list == null || list.isEmpty()) {
            %>
            <tr><td colspan="3">No members registered yet.</td></tr>
            <%
            } else {
                for (Map<String, String> person : list) {
            %>
            <tr>
                <td><%= person.get("name")%></td>
                <td><%= person.get("matric")%></td>
                <td><%= person.get("club")%></td>
            </tr>
            <%
                    }
                }
            %>
        </table>

        <br>
        <a href="registerClub.jsp">Register Another Member</a>

        <%@ include file="footer.jsp" %>
    </body>
</html>